# Inventory Management System

**CS312 – Modern Development Tools | GUI Design Stage**

## Project Overview

The **Inventory Management System** is a desktop application built with C# and Windows Forms (.NET 8). It helps a business track products, manage suppliers, record stock movements and view reports, through a simple graphical interface.

> **Submission note:** this archive is the **GUI Design stage** submission. All screens are fully designed and open in the Visual Studio Designer. The project also contains working logic (database, login, CRUD), but full functionality is not required at this stage.

## Technologies Used

- **Language:** C#
- **Framework:** .NET 8 (`net8.0-windows`)
- **Application type:** Windows Forms desktop application
- **Database:** SQLite via `Microsoft.Data.Sqlite` (NuGet, restored automatically)
- **IDE:** Visual Studio 2022

## Main Features

1. **Dashboard** – KPI cards, a category donut chart and a bar chart, plus a low-stock alerts list.
2. **Products** – add, edit, delete, live search and low/out-of-stock filter, quantities and prices.
3. **Suppliers** – add, edit, delete and search suppliers with contact details.
4. **Stock Movements** – stock-in / stock-out operations with a searchable movement history.
5. **Reports** – five inventory reports with totals, average, minimum and maximum, and CSV export.
6. **Settings** – SMTP configuration for low-stock e-mail alerts.
7. **Authentication and user management** – first-run administrator setup, login, change password, and admin-only user management.

## Project Structure

```text
CS312_54_200041181_GUI/
├── README.md
├── InventoryManager.sln
└── InventoryManager/
    ├── InventoryManager.csproj
    ├── Program.cs                 Entry point
    ├── MainForm.cs / .Designer.cs Main window (tab control)
    ├── DashboardPanel      (.cs / .Designer.cs)
    ├── ProductsPanel       (.cs / .Designer.cs)
    ├── SuppliersPanel      (.cs / .Designer.cs)
    ├── MovementsPanel      (.cs / .Designer.cs)
    ├── ReportsPanel        (.cs / .Designer.cs)
    ├── SettingsPanel       (.cs / .Designer.cs)
    ├── KpiCard.cs, BarChart.cs, DonutChart.cs   Custom GDI+ controls
    ├── Db.cs, AlertService.cs, Ui.cs            Database, alerts, helpers
    └── Auth/
        ├── LoginForm, FirstAdminSetupForm, ChangePasswordForm, UserManagementForm
        │   (each with .cs / .Designer.cs)
        ├── BrandHeader.cs         Custom header control
        └── AuthService, UserService, PasswordHasher, ... (authentication logic)
```

## Forms to Review in the Designer (View Designer)

| Screen | File |
|--------|------|
| Main window | `MainForm.cs` |
| Dashboard, Products, Suppliers, Stock Movements, Reports, Settings | `*Panel.cs` (UserControls shown as tabs) |
| Login, First administrator setup, Change password, Manage users | `Auth/*Form.cs` |

**How to open the Designer:** first run **Build → Rebuild Solution** (the custom controls `KpiCard`, `BarChart`, `DonutChart` and `BrandHeader` must be compiled), then right-click any `.cs` file and choose **View Designer**.

## Requirements

- Windows 10 or Windows 11
- Visual Studio 2022 with the ".NET desktop development" workload
- .NET 8 SDK
- Internet access on first build (NuGet restore)

## Installation and Setup

1. Extract the ZIP file.
2. Open `InventoryManager.sln` in Visual Studio 2022.
3. Wait for NuGet package restore to finish.
4. Choose **Build → Rebuild Solution**.
5. Press **F5** to run.

**First run:** there is no default account. The app asks you to create the first administrator, then shows the login screen.

## Database

SQLite is used for local storage. The database file is created automatically on first run at:

`%LOCALAPPDATA%\InventoryManager\inventory.db`

Tables: `Suppliers`, `Products`, `StockMovements`, `Settings`, `Users`. Passwords are stored as salted PBKDF2 hashes, never as plain text.

## Academic Information

- **Course:** CS312 – Modern Development Tools
- **Project title:** Inventory Management System
- **Project type:** Desktop application (GUI Design stage)
- **Framework:** C# Windows Forms (.NET 8)
- **Institution:** Misr University for Science and Technology (MUST)
- **Group number:** 54

**Team members:**

| Name | Student ID |
|------|-----------|
| Donia Ashraf | 200041181 |
| Fares Ahmed | 200042841 |
| Nada Osama | 200043782 |
| Ziad Amr | 200054096 |
| Mohamed Amr | 200053998 |
| Mark John | 200036305 |

## License

Developed for academic purposes as part of the CS312 – Modern Development Tools course.
